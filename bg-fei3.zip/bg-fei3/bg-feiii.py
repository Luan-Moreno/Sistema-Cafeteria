from datetime import datetime # Importa a classe datetime do módulo datetime
import time # Importa o módulo de tempo nativo do Python

def menu_op():  # Função que imprime o menu de opções
    print('\n' + "1 - Novo Pedido")
    print("2 - Cancelar Pedido")
    print("3 - Inserir produto")
    print("4 - Cancelar produto")
    print("5 - Valor do pedido")
    print("6 - Extrato do pedido" + '\n')
    print("0 - Sair" + '\n')


def menu_pd():   # Função que imprime o menu do pedido

    matriz = [["1", "X-Salada", "R$ 10,00"], ["2", "X-burger", "R$ 10,00"], ["3", "Cachorro quente", "R$ 7,50"],
              ["4", "Misto quente", "R$ 8,00"], ["5", "Salada de frutas", "R$ 5,50"],
              ["6", "Refrigerante", "R$ 4,50"], ["7", "Suco natural", "R$ 6,25"]]

    for linha in range(len(matriz)): # Pega cada elemento da matriz, pega cada string dentro desse elemento e imprime
        # cada string de forma ordenada e separada para imprimir o menu do pedido
        y = matriz[linha]
        print("    {} │ {} │ {}" .format(y[0].ljust(1), y[1].ljust(16), y[2]))


def verificar(x):  # Verifica o input do usuário
    try:  # Tenta transformar o input do usuário em float
        float(x)
        numeros = True  # Se conseguir, modifica a váriavel numeros

    except ValueError:
        numeros = False  # Se retorna erro, modifica a váriavel numeros

    return numeros # Retorna True or False


def novo_pd():  # Função que pede, verifica e salva os dados do cliente para fazer um novo pedido completo
    arquivo = open("dados_cliente.txt", "r")
    # Abre o arquivo dados_cliente para leitura
    arquivo2 = open("dados_cliente2.txt", "a")
    # Abre o arquivo dados_cliente2 para acrescentar texto
    pt = 0
    pc = 0
    pd = ''
    p = 0
    verificador = True
    nome = input("Digite seu nome: ")
    # Solicita o nome

    numeros = verificar(nome) # Chama a função 'verificar' e verifica o nome

    while numeros is True or len(nome) < 1:
        print('Seu nome deve possuir apenas letras')
        nome = input("Digite seu nome: ")
        numeros = verificar(nome)  # Chama a função 'verificar' e verifica o nome

    cpf = input("Digite seu CPF: ")

    numeros = verificar(cpf)  # Chama a função verificar e verifica o CPF

    while len(str(cpf)) != 11 or numeros is False:  # Verifica o retorno de 'numeros' e o tamanho da string e repete as
        # solicitações enquanto os requerimentos não forem atingidos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = input("Digite seu CPF: ")
        numeros = verificar(cpf)

    cpff = str(cpf)
    cpfff = cpff + "\n"
    for llinha in arquivo.readlines():  # Verifica cada linha, se encontrar o mesmo CPF, não realiza o pedido
        if cpfff == llinha:
            verificador = False
            print("Já há um pedido nesse CPF.")
            arquivo.close()
            arquivo2.close()

    if verificador: # Caso não encontre o mesmo CPF, continua o pedido
        senha = input("Digite sua senha: ")
        numeros = verificar(senha)

        while len(str(senha)) < 4 or numeros is False: # Verifica se a senha tem apenas números e possui 4 caracteres
            print("Sua senha deve ser formada apenas por números e possuir pelo menos 4 dígitos")
            senha = input("Digite sua senha: ")
            numeros = verificar(senha)

        arquivo = open("dados_cliente.txt", "a") # Chama 'dados_cliente' e adiciona nome, cpf e senha
        arquivo.write('\n' + "{}".format(cpff) + '\n')
        arquivo.write("{}".format(nome) + '\n')
        arquivo.write("{}".format(senha) + '\n')
        arquivo.write("---" + '\n')
        arquivo.close() # Fecha dados_cliente
        arquivo2.write(cpff + '\n')
        arquivo2.close() # Fecha dados_cliente2
        menu_pd()  # Chama o menu de pedidos

        while True:  # Roda enquanto o cliente não pedir para sair
            codigo = int(input("Digite o código do produto: "))
            quantidade = int(input("Digite a quantidade: "))
            arquivo = open("dados_cliente.txt", "a")
            arquivo2 = open("dados_cliente2.txt", "a")

            if quantidade > 99:  # Limita que o cliente só possa pedir 99 itens por vez de certo produto
                print("Você não pode pedir {} unidades. O máximo é 99 unidades por código.".format(quantidade))
                break

            if codigo == 1:  # Verifica o código digitado pelo usuário e relaciona com as informações do produto
                pd = "X-Salada(s)"
                pc = 10.0

            elif codigo == 2:
                pd = "X-burger(s)"
                pc = 10.0

            elif codigo == 3:
                pd = "Cachorro(s) quente(s)"
                pc = 7.50

            elif codigo == 4:
                pd = "Misto(s) quente(s)"
                pc = 8.00

            elif codigo == 5:
                pd = "Salada(s) de frutas"
                pc = 5.50

            elif codigo == 6:
                pd = "Refrigerante(s)"
                pc = 4.50

            elif codigo == 7:
                pd = "Suco(s) natural(is)"
                pc = 6.25

            else:  # Caso o cliente digite um código não existente
                print("Digite um código de produto existente!")

            pf = pc * quantidade
            n = input("Deseja adicionar algo além de {} {}?: ".format(quantidade, pd))  # Condição para sair ou continuar o pedido
            arquivo.write("  * ")
            arquivo.write("{}-{}".format(codigo, quantidade))  # Salva os dados em dados_cliente
            arquivo.write("  * ")
            pt += pf # Salva o preço total até o momento
            p += 1
            if (n == "nao") or n == "n":  # Saída do novo pedido
                arquivo.write('\n' + str(pt) + '\n')
                arquivo.write("{}".format(p) + '\n')
                arquivo.write("Final do Pedido{}".format(cpff) + "\n")
                arquivo2.write(str(pt) + '\n')
                arquivo.close()
                arquivo2.close()
                break


def cancela_pd():  # Função que pede e verifica dados do cliente para cancelar um pedido completo
    arquivo = open("dados_cliente.txt", "r+")
    arquivo2 = open("dados_cliente2.txt", "r+")
    cpf = int(input("Digite seu CPF: "))
    cpff = str(cpf)
    cpfff = cpff + "\n"

    while len(str(cpf)) != 11:  # Limita o CPF a ter 11 digitos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = int(input("Digite seu CPF: "))

    senha = input("Digite sua senha: ")
    senhaa = str(senha)
    senhaaa = senhaa + "\n"
    s = 0
    d = 0
    L = []
    L2 = []

    while len(str(senha)) < 4: # Limita a senha a ter pelo menos 4 caracteres
        print("Sua senha deve possuir pelo menos 4 dígitos")
        senha = input("Digite sua senha: ")

    for linha in arquivo.readlines(): # Verifica se senha e CPF são válidos
        if linha == cpfff:
            s += 1
            print("CPF validado")
        if linha == senhaaa:
            s += 1
            print("Senha validada")

    if s >= 2:
        arquivo = open("dados_cliente.txt", "r+")
        for linha in arquivo.readlines(): # Cria uma matriz com os elementos de dados_cliente
            L.append(linha.split('*'))
        for linha2 in arquivo2.readlines(): # Cria uma matriz com os elementos de dados_cliente2
            L2.append(linha2.splitlines())

        for l in range(len(L)):
            for ll in range(len(L[l])):
                if L[l][ll] == cpfff:  # Identifica o CPF do cancelamento e apaga ele e os dados associados da matriz L
                    L[l] = []
                    L[l + 1] = []
                    L[l + 2] = []
                    L[l + 3] = []
                    L[l + 4] = []
                    L[l + 5] = []
                    L[l + 6] = []
                    L[l + 7] = []

                if L[l] == "\n":  # Apaga alguns espaçamentos desnecessários
                    L[l][ll] = ''

        for l in range(len(L2)):
            for ll in range(len(L2[l])):
                if L2[l][ll] == cpff:  # Identifica o CPF do cancelamento e apaga ele e os dados associados da matriz L2
                    L2[l] = []
                    L2[l + 1] = []

        arquivo = open("dados_cliente.txt", "w")
        print("Pedido Cancelado!")

        for l in range(len(L)):  # Reescreve o arquivo dados_cliente através da matriz sem esses elementos
            for ll in range(len(L[l])):
                arquivo.write(L[l][ll])

        arquivo2 = open("dados_cliente2.txt", "w")

        for l in range(len(L2)): # Reescreve o arquivo dados_cliente2 através da matriz sem esses elementos
            for ll in range(len(L2[l])):
                arquivo2.write(L2[l][ll])
                arquivo2.write("\n")

        arquivo.close()
        arquivo2.close()

    else:
        while (s != 2) and (d < 11): # Apenas roda se os dados estiverem incorretos, se ocorre +10 vezes, volta ao menu
            print("Algum dos dados está incorreto! (CPF/Senha)")
            cpf = int(input("Digite seu CPF: "))
            senha = input("Digite sua senha: ")
            d += 1
        print("Erro! Mais de 10 tentativas, Voltando ao Menu")


def adiciona_pdt():  # Função que pede, verifica e salva os dados do cliente para adicionar um item ao pedido
    pc = 0
    pd = ''
    pt = 0
    p = 0
    G = []
    s = 0
    d = 0
    arquivo = open("dados_cliente.txt", "r+")

    cpf = int(input("Digite seu CPF: "))
    cpff = str(cpf)
    cpfff = cpff + "\n"

    while len(str(cpf)) != 11:  # Limita o CPF a ter 11 digitos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = int(input("Digite seu CPF: "))

    senha = input("Digite sua senha: ")
    senhaa = str(senha)
    senhaaa = senhaa + "\n"
    if len(str(senha)) < 9999:
        while len(str(senha)) < 4:  # Limita a senha a ter pelo menos 4 caracteres
            print("Sua senha deve possuir pelo menos 4 dígitos")
            senha = input("Digite sua senha: ")

    for linha in arquivo.readlines():
        if linha == senhaaa:
            s += 1
        if linha == cpfff:
            s += 1

    if s >= 2:
        menu_pd()
        while True:  # Roda enquanto o cliente não pedir para sair
            codigo = int(input("Digite o código do produto: "))
            quantidade = int(input("Digite a quantidade: "))

            if quantidade > 99:  # Limita que o cliente só possa pedir 99 itens por vez de certo produto
                print("Você não pode pedir {} unidades desse produto de uma vez. O máximo é 99 unidades por código.".format(quantidade))
                break

            if codigo == 1:  # Verifica o código digitado pelo usuário e relaciona com as informações do produto
                pd = "X-Salada(s)"
                pc = 10.0

            elif codigo == 2:
                pd = "X-burger(s)"
                pc = 10.0

            elif codigo == 3:
                pd = "Cachorro(s) quente(s)"
                pc = 7.50

            elif codigo == 4:
                pd = "Misto(s) quente(s)"
                pc = 8.00

            elif codigo == 5:
                pd = "Salada(s) de frutas"
                pc = 5.50

            elif codigo == 6:
                pd = "Refrigerante(s)"
                pc = 4.50

            elif codigo == 7:
                pd = "Suco(s) natural(is)"
                pc = 6.25

            else:  # Caso o cliente digite um código não existente
                print("Digite um código de produto existente!")
                adiciona_pdt()
                menu_op()

            G.append("* ")
            pf = pc * quantidade
            n = input("Deseja adicionar algo além de {} {}?: ".format(quantidade, pd))
            G.append(' ' + "{}-{}".format(codigo, quantidade))
            G.append("  * ")
            pt += pf
            p += 1
            if (n == "nao") or (n == "n"):
                break

        arquivo = open("dados_cliente.txt", "r+")

        L = []
        L2 = []
        z = ""
        arquivo2 = open('dados_cliente2.txt', 'r+')
        for linha in arquivo2.readlines():  # Gera uma matriz com os elementos de dados_cliente2
            L2.append(linha.split("---"))

        for l in range(len(L2)):
            for ll in range(len(L2[l])):
                if L2[l][ll] == cpfff:
                    # Acessa o valor de preço total, salva em y, soma o preço total dos valores adicionados e transforma o valor inicial no novo valor de z
                    y = str(L2[l + 1])[:-4]
                    z = y.strip("['")
                    y = round(float(z))
                    z = str(y + pt)
                    L2[l + 1] = str(z + "\n")

        for linha in arquivo.readlines():  # Gera uma matriz com os elementos de dados_cliente
            L.append(linha.split("---"))

        for h in range(len(L)):
            for hh in range(len(L[h])):
                if L[h][hh] == cpfff:  # Identifica o CPF e através dele: Pega os pedidos e adiciona os produtos a mais + Modifica o preço final
                    L[h + 3].extend(G)
                    L[h + 5] = str(z + "\n")

        arquivo = open("dados_cliente.txt", "w")
        arquivo2 = open("dados_cliente2.txt", "w")

        for l in range(len(L)):  # Reescreve o arquivo dados_cliente através da nova matriz
            for ll in range(len(L[l])):
                arquivo.write(L[l][ll])

        for l in range(len(L2)):  # Reescreve o arquivo dados_cliente2 através da nova matriz
            for ll in range(len(L2[l])):
                arquivo2.write(L2[l][ll])

        arquivo.close()
        arquivo2.close()
    else:
        while (s != 2) and (d < 11):
            print("Algum dos dados está incorreto! (CPF/Senha)")
            cpf = int(input("Digite seu CPF: "))
            senha = input("Digite sua senha: ")
            d += 1
        print("Erro! Mais de 10 tentativas, Voltando ao Menu")


def cancela_pdt(): # Função que pede, verifica e salva os dados do cliente para cancelar um item do pedido
    cpf = int(input("Digite seu CPF: "))
    cpff = str(cpf)
    cpfff = cpff + "\n"
    s = 0
    d = 0
    e = 0
    arquivo = open("dados_cliente.txt", "r+")
    k = []
    k2 = []
    L = []
    L2 = []
    pn = 0
    pc = 0

    while len(str(cpf)) != 11:  # Limita o CPF a ter 11 digitos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = int(input("Digite seu CPF: "))

    senha = input("Digite sua senha: ")
    senhaa = str(senha)
    senhaaa = senhaa + "\n"

    while len(str(senha)) < 4: # Limita a senha a ter pelo menos 4 caracteres
        print("Sua senha deve possuir pelo menos 4 dígitos")
        senha = input("Digite sua senha: ")

    for linha in arquivo.readlines():
        if linha == senhaaa:
            s += 1
        if linha == cpfff:
            s += 1

    if s >= 2:
        menu_pd()
        codigo = int(input("Digite o código do produto: "))
        quantidade = int(input("Digite a quantidade: "))
        arquivo = open("dados_cliente.txt", "r+")

        for linha in arquivo.readlines():  # Gera uma matriz com os elementos de dados_cliente
            L.append(linha)

        for h in range(len(L)): # Gera uma matriz com os pedidos de dados_cliente
            if L[h] == cpfff:
                k.append(str(L[h + 4]))

        x = str(k[0]).split() # Gera uma string com os pedidos
        y = '{}-{}'.format(codigo, quantidade)

        for n in range(len(x)):  # Na range do tamanho da string
            for j in range(1, 100): # Com j valendo de 1 a 99
                if(x[n] == '{}-{}'.format(codigo, j)):
                    # Se um tal elemento N em x, for igual ao código + um número variando de 1 a 99
                    if(j > quantidade and e < 1): # Se esse número for maior que a quantidade pedida e for a 1a vez
                        z = j - quantidade # Retira quantidade do valor do número variando de 1 a 99
                        x.append('$' + x[n] + '$')
                        # Adiciona ao final o pedido atual, e usa $ para representar o cancelamento
                        x[n] = '{}-{}'.format(codigo, z) # Reescreve o que está na posição para o valor reduzido
                        if(codigo == 1) or (codigo == 2): # Associa os códigos com seus respectivos preços
                            pc = 10
                        elif codigo == 3:
                            pc = 7.5
                        elif codigo == 4:
                            pc = 8
                        elif codigo == 5:
                            pc = 5.5
                        elif codigo == 6:
                            pc = 4.5
                        elif codigo == 7:
                            pc = 6.25
                        pn += int(pc * float(quantidade))
                        e += 1
                        break

                    elif (j == quantidade and e < 1): # Caso a quantidade seja igual a esse valor variado e seja a 1a vez
                        x.append('$' + x[n] + '$') # Adiciona o pedido atual ao fim da string
                        x[n] = '' # Remove o que está na posição
                        if (codigo == 1) or (codigo == 2): # Associa os códigos com seus respectivos preços
                            pc = 10
                        elif codigo == 3:
                            pc = 7.5
                        elif codigo == 4:
                            pc = 8
                        elif codigo == 5:
                            pc = 5.5
                        elif codigo == 6:
                            pc = 4.5
                        elif codigo == 7:
                            pc = 6.25
                        pn += int(pc * float(quantidade))
                        e += 1
                        break
                    else: # Se quantidade > j
                        print("Não existe essa quantidade de itens nesse pedido!")
                        x[n] = x[n]
                        break

        e = 0

        for h in range(len(L)):
            if L[h] == cpfff: # Adiciona uma quebra de linha dentro de L[h +4]
                L[h + 4] = x
                L[h + 4] = str(L[h + 4]).replace('[', '')
                L[h + 4] = str(L[h + 4]).replace(']', '')
                L[h + 4] = str(L[h + 4]).replace("'", '')
                L[h + 4] = str(L[h + 4]).replace(',', '')
                L[h + 4] = str(L[h + 4]) + str('\n')

        arquivo = open("dados_cliente.txt", "w")
        for l in range(len(L)): # Reescreve dados_cliente
            for ll in range(len(L[l])):
                arquivo.write(L[l][ll])

        for h in range(len(L)):
            if L[h] == cpfff: # Modifica o preço
                if(pn != 0):
                    o = str(L[h + 5]).strip('\n')
                    o = o.strip("'")
                    o = float(o)
                    L[h + 5] = str(o - pn) + str('\n')

        arquivo2 = open("dados_cliente2.txt", "r+")
        for linha in arquivo2.readlines():  # Gera uma matriz com os elementos de dados_cliente2
            L2.append(linha)

        for h in range(len(L2)): # Modificado a matriz de dados_cliente2 com os dados de dados_cliente
            if L2[h] == cpfff:
                L2[h + 1] = L[h + 7]

        arquivo = open("dados_cliente.txt", "w") # Escreve o resultado em dados_cliente
        for l in range(len(L)):
            arquivo.write(str(L[l]))

        arquivo2 = open("dados_cliente2.txt", "w") # Escreve o resultado em dados_cliente2
        for l in range(len(L2)):
            arquivo2.write(str(L2[l]))

    else:
        while (s != 2) and (d < 11):
            print("Algum dos dados está incorreto! (CPF/Senha)")
            cpf = int(input("Digite seu CPF: "))
            senha = input("Digite sua senha: ")
            d += 1
        print("Erro! Mais de 10 tentativas, Voltando ao Menu")


def ops():  # Função que pergunta a opção e a executa
    x = 10
    while x != 0:  # Loop condicional enquanto o cliente não escolher 0
        print()
        x = int(input("Digite a opção: "))

        print()
        print()

        if x == 1:  # Opção 1
            novo_pd()
            menu_op()

        if x == 2:  # Opção 2
            cancela_pd()
            menu_op()

        if x == 3:  # Opção 3
            adiciona_pdt()
            menu_op()

        if x == 4:  # Opção 4
            cancela_pdt()

        if x == 5:  # Opção 5
            mostra_preco()

        if x == 6:  # Opção 6
            mostra_extrato()

        if x == 2022:
            print("Entrando em Modo Desenvolvedor...")
            time.sleep(1.5)
            print("&&&&&&&&&&#################-//////\n" * 30)
            time.sleep(0.5)
            print("--\---\-----\------\---\----\-----\n" * 30)
            time.sleep(1)
            limpeza()


def mostra_preco():  # Função que imprime o valor total a pagar
    cpf = int(input("Digite seu CPF: "))
    cpff = str(cpf)
    cpfff = cpff + "\n"

    while len(str(cpf)) != 11:  # Limita o CPF a ter 11 digitos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = int(input("Digite seu CPF: "))

    senha = input("Digite sua senha: ")
    senhaa = str(senha)
    senhaaa = senhaa + "\n"

    while len(str(senha)) < 4:  # Limita a senha a ter pelo menos 4 caracteres
        print("Sua senha deve possuir pelo menos 4 dígitos")
        senha = input("Digite sua senha: ")

    s = 0
    d = 0
    arquivo = open("dados_cliente.txt", "r+")
    L = []

    for linha in arquivo.readlines(): # Verifica CPF e Senha
        if linha == senhaaa:
            s += 1
        if linha == cpfff:
            s += 1

    if s == 2:
        arquivo = open("dados_cliente.txt", "r+")

        for l in arquivo.readlines(): # Cria uma matriz com dados_cliente2
            L.append(l.splitlines())

        for h in range(len(L)):
            for hh in range(len(L[h])):
                if L[h][hh] == cpff: # A partir da posição do CPF, pega o valor de preço total
                    preco = L[h + 5][0]
                    print("\n")
                    print("------------------------------------")
                    print("O valor a pagar é R$ {}".format(preco))
                    print("------------------------------------")

    else:
        while(s != 2) and (d < 11):
            print("Algum dos dados está incorreto! (CPF/Senha)")
            cpf = int(input("Digite seu CPF: "))
            senha = input("Digite sua senha: ")
            d += 1
        print("Erro! Mais de 10 tentativas, Voltando ao Menu")


def mostra_extrato():
    cpf = int(input("Digite seu CPF: "))
    cpff = str(cpf)
    cpfff = cpff + "\n"

    while len(str(cpf)) != 11:  # Limita o CPF a ter 11 digitos
        print("O seu CPF deve ser formado apenas por números e possuir 11 dígitos")
        cpf = int(input("Digite seu CPF: "))

    senha = input("Digite sua senha: ")
    senhaa = str(senha)
    senhaaa = senhaa + "\n"
    s = 0
    d = 0
    preco = 0
    arquivo = open("dados_cliente.txt", "r+")
    L = []
    L2 = []
    nome = ''
    cd = 0
    qt = 0
    pt = 0

    while len(str(senha)) < 4:  # Limita a senha a ter pelo menos 4 caracteres
        print("Sua senha deve possuir pelo menos 4 dígitos")
        senha = input("Digite sua senha: ")

    for linha in arquivo.readlines():
        if linha == senhaaa:
            s += 1
        if linha == cpfff:
            s += 1

    if s >= 2:
        arquivo = open("dados_cliente.txt", "r+")
        arquivo2 = open("dados_cliente2.txt", "r+")

        for l in arquivo.readlines(): # Matriz de dados_cliente
            L.append(l.splitlines())

        for l2 in arquivo2.readlines(): # Matriz de dados_cliente2
            L2.append(l2.splitlines())

        for h in range(len(L2)):
            for hh in range(len(L2[h])):
                if L2[h][hh] == cpff: # Pega o valor de preço a partir da matriz de dados_cliente 2
                    preco = L2[h + 1][0]

        for l in range(len(L)):
            for ll in range(len(L[l])):
                if L[l][ll] == cpff:  # A partir da posição do CPF, pega o nome a partir da matriz de dados_cliente
                    nome = L[l + 1][0]

        print("Nome: {}".format(nome))
        print("CPF: {}".format(cpff)) # Acessa o valor já fornecido pelo usuário, sabendo que ele foi verificado
        print("Total: R$ {}".format(preco))
        print("Data: {}".format(datetime.today().replace(microsecond=0))) # Imprime a data do momento sem os milissegundos
        print("Itens do Pedido: ")

        k = []
        for l in range(len(L)):
            for ll in range(len(L[l])):
                if L[l][ll] == cpff:  # A partir da posição do CPF, pega o nome
                    k.extend(L[l + 4])

        k2 = []
        k3 = []

        for l in range(len(k)): # Separa os pedidos ativos em uma matriz k2
            k2.append(str(k[l]).split('*'))

        for l in range(len(k)): # Separa os pedidos cancelados em uma matriz k3
            k3.append(str(k[l]).split('$'))

        k4 = []
        k5 = []
        pc = 0
        pd = 0

        for l in range(len(k2)): # Separa a matriz k2, retira o último elemento e remove os espaços vazios, fazendo k4
            for ll in range(len(k2[l])):
                if(k2[l][ll] != k2[0][-1]):
                    if (k2[l][ll] != '' and k2[l][ll] != ' '):
                        k4.extend(k2[l][ll])

        for l in range(len(k3)):  # Separa a matriz k3, retira o último elemento e remove os espaços vazios, fazendo k5
            for ll in range(len(k3[l])):
                if (k3[l][ll] != '' and k3[l][ll] != ' '):
                    k5.extend(k3[l][ll])

        for l in range(len(k4)): # Confirma que k4 não está pegando valores vazios
            if (k4[l] != '' and k4[l] != ' '):
                if(k4[l - 1] == ' ' and k4[l + 1] != ' ' ):
                    cd = int(k4[l])
                    if cd == 1:  # Verifica o código digitado pelo usuário e relaciona com as informações do produto
                        pd = "X-Salada"
                        pc = 10.0

                    elif cd == 2:
                        pd = "X-burger"
                        pc = 10.0

                    elif cd == 3:
                        pd = "Cachorro quente"
                        pc = 7.50

                    elif cd == 4:
                        pd = "Misto quente"
                        pc = 8.00

                    elif cd == 5:
                        pd = "Salada de frutas"
                        pc = 5.50

                    elif cd == 6:
                        pd = "Refrigerante"
                        pc = 4.50

                    elif cd == 7:
                        pd = "Suco natural"
                        pc = 6.25
                elif(k4[l - 1] == '-'): # Verifica se o elemento anterior é '-' se for, o elemento é a quantidade
                    qt = int(k4[l])
                    pf = pc * qt # Pega o valor final através do preço * quantidade
                    t = 'Preço Unitário:'
                    t2 = 'Valor:'
                    print(
                        "{} - {} - {}  {}  {}  +{}".format(qt, pd.ljust(20), t.ljust(20), str(pc).ljust(10), t2.ljust(20), pf))

        for l in range(len(k5)): # O mesmo esquema anterior de k4 com diferenças de espaço para os pedidos cancelados
            if (k5[l] != '' and k5[l] != ' '):
                if(k5[l - 1] == ' ' and k5[l + 1] != ' '):
                    cd = int(k5[l])
                    if cd == 1:  # Verifica o código digitado pelo usuário e relaciona com as informações do produto
                        pd = "X-Salada"
                        pc = 10.0

                    elif cd == 2:
                        pd = "X-burger"
                        pc = 10.0

                    elif cd == 3:
                        pd = "Cachorro quente"
                        pc = 7.50

                    elif cd == 4:
                        pd = "Misto quente"
                        pc = 8.00

                    elif cd == 5:
                        pd = "Salada de frutas"
                        pc = 5.50

                    elif cd == 6:
                        pd = "Refrigerante"
                        pc = 4.50

                    elif cd == 7:
                        pd = "Suco natural"
                        pc = 6.25
                elif(k5[l - 1] == '-'):
                    qt = int(k5[l])
                    pf = pc * qt
                    t = 'Preço Unitário:'
                    t2 = 'Valor:'
                    print("{} - {} - {}  {}  {}  -{} - Cancelado".format(qt, pd.ljust(20), t.ljust(20), str(pc).ljust(10), t2.ljust(20), pf))

    else:
        while (s != 2) and (d < 11):
            print("Algum dos dados está incorreto! (CPF/Senha)")
            cpf = int(input("Digite seu CPF: "))
            senha = int(input("Digite sua senha: "))
            d += 1
        print("Erro! Mais de 10 tentativas, Voltando ao Menu")


def limpeza(): # Limpa todos os arquivos (Extra)
    senha = input("Digite o código de desenvolvedor: ")
    if(senha != 'HamburgueriaFEI202204'):
        print("ERRO! SENHA INCORRETA! VOLTANDO AO MENU")
        menu_op()
        ops()
    else:
        print()
        confirma = int(input("Você confirma a operação?: "))
        print()
        if(confirma == 1):
            arquivo = open('dados_cliente.txt', 'w')
            arquivo2 = open('dados_cliente2.txt', 'w')
            arquivo.write('') # Limpa dados_cliente
            arquivo2.write('') # Limpa dados_cliente2
            print("Arquivos Deletados com Sucesso!")
        else:
            print("Operação Cancelada...VOLTANDO AO MENU")
            menu_op()
            ops()


print()
menu_op()  # Apresenta a primeira vez o menu de opções
ops()  # Apresenta a primeira vez as opções
